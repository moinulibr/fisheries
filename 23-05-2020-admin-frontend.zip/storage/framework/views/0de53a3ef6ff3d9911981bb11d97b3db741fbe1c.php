
<!-- The Modal -->

    
 



<!-- Modal -->

    
    <form action="<?php echo e(route('admin.important.link.update',$inportLink->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-dialog">
            <div class="modal-content modal-lg">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Update Important Link</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
            
                    <div class="postbody">
                        <h5>Update Link</h5>
                        <div class="mb-3">
                            <label for="exampleFormControlText" class="form-label">Link Name</label>
                            <input  required name="link_name" value="<?php echo e($inportLink->link_name); ?>" type="text" class="form-control" id="exampleFormControlText" placeholder="">
                            The name is how it appears on your site.
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlText" class="form-label">Site URL</label>
                        <input required  name="side_url" value="<?php echo e($inportLink->side_url); ?>" type="text" class="form-control" id="exampleFormControlText" placeholder="">
                        <p>The “Site URL” is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="submit" value="Update Link"  class="btn btn-primary">
                </div>
            </div>
        </div>
    </form>
<?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/important-link/edit.blade.php ENDPATH**/ ?>