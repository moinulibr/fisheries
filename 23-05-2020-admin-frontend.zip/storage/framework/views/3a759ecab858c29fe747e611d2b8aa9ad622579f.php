

<?php $__env->startSection('content'); ?>
			<!-- start page content wrapper-->
			<div class="page-content-wrapper">
				<!-- start page content-->
				<div class="page-content">
					<!--start breadcrumb-->
					<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
						<div class="breadcrumb-title pe-3">Edit Page  
                            <a href="<?php echo e(route('admin.page.index')); ?>" class="btn btn-sm btn-outline-secondary">Page List</a>
                            <a href="<?php echo e(route('admin.page.create')); ?>" class="btn btn-sm btn-outline-secondary">Add New</a> 
                        </div>
						<div class="ms-auto">
							
						</div>
					</div>
					<!--end breadcrumb-->

					<hr />

					<div class="card">
						<div class="card-body">
							<form action="<?php echo e(route('admin.page.update',$page->id)); ?>" method="POST" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-9">
                                        <div class="postbody">
                                            <div class="mb-3">
                                            <input name="title" value="<?php echo e($page->title); ?>" class="form-control mb-2" type="text" placeholder="Add Title" aria-label="add title" />
                                                
                                            </div>
                                           
                                            <div id="">
                                                <textarea name="description" id="div_editor1" ><?php echo $page->description; ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="postbox mb-3">
                                            <div class="postbox-header">
                                                <h2>Publish</h2>
                                            </div>
                                            <div class="postbox-body">
                                                <input type="submit" name="page_status" value="Save Draft" class="btn btn-sm btn-outline-secondary mb-3">
                                                
                                                <div class="misc-pub-section mb-3"><i class="bi bi-bookmark-star"></i> Status: <span id="post-status-display"> 
                                                    <?php if($page->status == 1): ?>
                                                    Publish
                                                    <?php elseif($page->status == 2): ?>
                                                    Draft
                                                    <?php elseif($page->status == 0): ?>
                                                    Pending
                                                    <?php endif; ?>
                                                    </span>
                                                </div>
                                                <div class="misc-pub-section mb-3">
                                                    <i class="bi bi-calendar-day"></i> Date: <span id="post-status-display"> <?php echo e(date('d-m-Y',strtotime($page->created_at))); ?></span>
                                                </div>
                                                <div id="time" class="misc-pub-section mb-3">
                                                    <i class="bi bi-clock-history"></i> Time: <span id="post-status-display"> <?php echo e(date('h:s:i A',strtotime($page->created_at))); ?> </span>
                                                </div>
                                            </div>
                                            <div class="postbox-footer">
                                                
                                                <input type="submit"  name="page_status" value="Publish" class="d-inline btn btn-sm btn-outline-secondary">
                                            </div>
                                        </div>
                                
                                        <div class="postbox mb-5">
                                            <div class="postbox-header">
                                                <h2>Featured image</h2>
                                            </div>
                                            <div class="postbox-body">
                                                <!-- Button trigger modal -->
                                            
                                                <?php if($page->featured_image): ?>
                                                <img width="100%" height="90" src="<?php echo e(asset('storage/page/'.$page->featured_image)); ?>" class="attachment-60x60 size-60x60" alt="" loading="lazy">
                                                <?php else: ?>
                                                <img width="100%" height="90" src="" class="attachment-60x60 size-60x60" alt="" loading="lazy">
                                                <?php endif; ?>
                                                <img id="blah"  />
                                                <input type='file' name="featured_image" onchange="readURL(this);" style="margin-top: 10px;" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
						</div>
					</div>
					<!--end card-->
				</div>
				<!-- end page content-->
			</div>
			<!--end page content wrapper-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.dashboard.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/pages/edit.blade.php ENDPATH**/ ?>