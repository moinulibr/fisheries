

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-5 col-lg-6 col-md-7 mx-auto">
            <div class="reset-passowrd">
                <div class="card radius-10 w-100 mt-8">
                    <div class="card-header">Reset Password</div>
                    <div class="card-body p-4">
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(Session::get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <form class="form-body row g-3" action="<?php echo e(route('reset.password.post')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        <input type="text" name="token" value="<?php echo e($token); ?>" hidden>
                          <div class="col-12">
                            <label for="email_address" class="form-label">E-Mail Address</label>
                            <input type="email" class="form-control" id="inputEmail" placeholder="abc@example.com" name="email" required autofocus >
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                          </div>

                          <div class="col-12">
                            <label for="password" class="form-label">New Password</label>
                            <input type="password" id="password" class="form-control" name="password" required autofocus  placeholder="New Password">
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                          </div>

                          <div class="col-12">
                            <label for="password-confirm" class="form-label">Confirm New Password</label>
                            <input type="password" id="password-confirm" class="form-control" name="password_confirmation" required autofocus placeholder="Confirm New Password" >
                            <?php if($errors->has('password_confirmation')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                            <?php endif; ?>
                          </div>

                          <div class="col-12 col-lg-12">
                            <div class="d-grid">
                                <button type="submit" class="btn btn-dark">Reset Password</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/auth/forgetPasswordLink.blade.php ENDPATH**/ ?>