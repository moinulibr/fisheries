  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">03 Notifiacations</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="item-content">
              <div class="media">
                  <div class="media-body space-sm">
                      <div class="post-title"><a href="post-details.php">        মাছ চাষ            </a>  </div>
                      <span>1 Mins ago</span>
                  </div>
              </div>
              <div class="media">
                  <div class="media-body space-sm">
                      <div class="post-title"><a href="post-details.php">         ভ্রাম্যমান মৎস্য হাসপাতাল       </a>     </div>
                      <span>20 Mins ago</span>
                  </div>
              </div>
              <div class="media">
                  <div class="media-body space-sm">
                      <div class="post-title"><a href="post-details.php">        মাছের রোগ ও চিকিৎসা                      </a> </div>
                      <span>45 Mins ago</span>
                  </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
