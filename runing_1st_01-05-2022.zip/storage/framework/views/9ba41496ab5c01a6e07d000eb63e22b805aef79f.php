

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-4 col-lg-5 col-md-7 mx-auto mt-5">
            <div class="card radius-10">
                <div class="card-body p-4">
                    <div class="text-center">
                        <h4>Sign In</h4>
                        <p>Sign In to your account</p>
                    </div>
                    <form class="form-body row g-3" method="post" action="<?php echo e(route('login.perform')); ?>">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                        <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="col-12 col-lg-12">
                            <div class="d-grid gap-2">
                                <a href="<?php echo e(route('social.oauth', 'google')); ?>" class="btn border border-2 border-dark"><img src="https://flid.org/rd/assets/img/icon/google.png" width="20" alt="" /><span class="ms-3 fw-500">Sign in with Google</span></a>
                            </div>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div class="position-relative border-bottom my-3">
                                <div class="position-absolute seperator-2 translate-middle-y">OR</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <label for="inputEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="inputEmail" value="<?php echo e(old('email')); ?>" placeholder="abc@example.com" required="required" autofocus>
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="col-12">
                            <label for="inputPassword" class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" id="inputPassword" value="<?php echo e(old('password')); ?>" placeholder="Your password" required="required">
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="col-12 col-lg-6">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="remember" value="1" role="switch" id="flexSwitchCheckRemember" >
                                <label class="form-check-label" for="flexSwitchCheckRemember">Remember Me</label>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6 text-end">
                            <a href="<?php echo e(route('forget.password.get')); ?>">Forgot Password?</a>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div class="d-grid">
                                <button  type="submit" class="btn btn-dark">Sign In</button>
                            </div>
                        </div>
                        <div class="col-12 col-lg-12 text-center">
                            <p class="mb-0">Don't have an account? <a href="<?php echo e(route('register.show')); ?>">Sign up</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/auth/login.blade.php ENDPATH**/ ?>