

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-5 col-lg-6 col-md-7 mx-auto">
            <div class="reset-passowrd">
                <div class="card radius-10 w-100 mt-8">
                    <div class="card-body p-4">
                        <div class="text-center">
                            <h4>Reset password</h4>
                            <p>You will receive an e-mail in maximum 60 seconds</p>
                        </div>
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(Session::get('message')); ?>

                            </div>
                        <?php endif; ?>
  
                      
                      <form class="form-body row g-3" action="<?php echo e(route('forget.password.post')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="col-12">
                            <label for="inputEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="inputEmail" placeholder="abc@example.com" name="email" required autofocus >
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="col-12 col-lg-12">
                            <div class="d-grid">
                                <button type="submit" class="btn btn-dark">Send</button>
                            </div>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend-layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend-auth/forgetPassword.blade.php ENDPATH**/ ?>