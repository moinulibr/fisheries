

    <form action="<?php echo e(route('admin.necessary.other.service.update',$otherService->id)); ?>" method="POST"  enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-dialog">
            <div class="modal-content modal-lg">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Other Service </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="postbody">
                        <div class="mb-3">
                            <label for="exampleFormControlText" class="form-label">Name</label>
                            <input required value="<?php echo e($otherService->title); ?>" name="title" type="text" class="form-control" id="exampleFormControlText" placeholder="">
                            The name is how it appears on your site.
                        </div>
        
                        <div class="mb-3">
                            <label for="exampleFormControlText" class="form-label">Site URL</label>
                            <input required value="<?php echo e($otherService->side_url); ?>" name="side_url" type="text" class="form-control" id="exampleFormControlText" placeholder="">
                            <p>The “Site URL” is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens.</p>
                        </div>

                        <div class="fileinput fileinput-new" data-provides="fileinput">
                            <?php if($otherService->photo): ?>
                            <img width="120" height="80" src="<?php echo e(asset('storage/other-service/'.$otherService->photo)); ?>" class="attachment-60x60 size-60x60" alt="" loading="lazy">
                            <?php else: ?>
                            <img width="120" height="80" src="https://motshoprani.org/wp-content/uploads/2022/03/received_297835542392423.jpeg" class="attachment-60x60 size-60x60" alt="" loading="lazy">
                            <?php endif; ?>
                        </div>
                        <hr>
                        <div class="fileinput fileinput-new" data-provides="fileinput">
                            <img id="blah"  />
                            <input type='file' name="photo" onchange="readURL(this);" style="margin-top: 10px;" />
                            <p>Maximum upload file size: 500 MB.</p>
                        </div>
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="submit" value="Update Other Service"  class="btn btn-primary">
                </div>
            </div>
        </div>
    </form><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/necessary-other-services/edit.blade.php ENDPATH**/ ?>