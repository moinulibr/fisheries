

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-5 col-lg-6 col-md-7 mx-auto mt-5">
          <div class="card radius-10">
            <div class="card-body p-4">
              <div class="text-center">
                <h4>Sign Up</h4>
                <p>Creat New account</p>
              </div>
              <form class="form-body row g-3" method="post" action="<?php echo e(route('register.perform')); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                <div class="col-12 col-lg-12">
                  <div class="d-grid gap-2">
                    <a href="javascript:;" class="btn border border-2 border-dark"><img src="https://flid.org/rd/assets/img/icon/google.png" width="20" alt="" /><span class="ms-3 fw-500">Sign in with Google</span></a>                    
                  </div>
                </div>
                <div class="col-12 col-lg-12">
                  <div class="position-relative border-bottom my-3">
                    <div class="position-absolute seperator-2 translate-middle-y">OR</div>
                  </div>
                </div>
                <div class="col-12">
                  <label for="inputName" class="form-label">Name</label>
                  <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" id="inputName" placeholder="Your name" required="required">
                  <?php if($errors->has('name')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="col-12">
                  <label for="inputEmail" class="form-label">Email</label>
                  <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" id="inputEmail" placeholder="abc@example.com" required="required">
                  <?php if($errors->has('email')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="col-12">
                  <label for="inputPassword"  class="form-label">Password</label>
                  <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" id="inputPassword" placeholder="Your password" required="required">
                  <?php if($errors->has('password')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                  <?php endif; ?>
                </div>
                <div class="col-12">
                    <label for="inputPassword" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="inputPassword" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Confirm Password" required="required">
                    <?php if($errors->has('password_confirmation')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('password_confirmation')); ?></span>
                    <?php endif; ?>
                  </div>
                <div class="col-12 col-lg-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked required>
                    <label class="form-check-label" for="flexCheckChecked">
                      I agree the Terms and Conditions
                    </label>
                  </div>
                </div>
                <div class="col-12 col-lg-12">
                  <div class="d-grid">
                    <button type="submit" class="btn btn-dark">Sign Up</button>
                  </div>
                </div>
                <div class="col-12 col-lg-12 text-center">
                  <p class="mb-0">Already have an account? <a href="<?php echo e(route('login.show')); ?>">Sign in</a></p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/auth/register.blade.php ENDPATH**/ ?>