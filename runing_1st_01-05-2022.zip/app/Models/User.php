<?php

namespace App\Models;

use App\Models\Backend\ImportantLink;
use App\Models\Backend\NecessaryOtherService;
use App\Models\Backend\NecessaryServiceBox;
use App\Models\Backend\PhotoMessage;
use App\Models\Backend\ScrollingNewsTicker;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
        'avatar', 'provider_id', 'provider',
        'access_token'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function scrollingNewsTickerUser()
    {
        return $this->hasMany(ScrollingNewsTicker::class,'created_by','id');
    }

    public function photoMessagerUser()
    {
        return $this->hasMany(PhotoMessage::class,'created_by','id');
    }

    public function importantLinkUser()
    {
        return $this->hasMany(ImportantLink::class,'created_by','id');
    }

    public function necessaryOtherServiceUser()
    {
        return $this->hasMany(NecessaryOtherService::class,'created_by','id');
    }

}
