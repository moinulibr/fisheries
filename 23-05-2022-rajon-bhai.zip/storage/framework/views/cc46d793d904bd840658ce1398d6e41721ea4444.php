<!-- Modal -->

    
    <form action="<?php echo e(route('admin.photo.message.status.changing',$photoMess->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="modal-dialog">
            <div class="modal-content modal-sm">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Change Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
            
                    <div class="postbody">
                        <?php if($photoMess->photo): ?>
                        <img width="120" height="80" src="<?php echo e(asset('storage/photo-messages/'.$photoMess->photo)); ?>" class="attachment-60x60 size-60x60" alt="" loading="lazy">
                        <?php else: ?>
                        <img width="120" height="80" src="https://motshoprani.org/wp-content/uploads/2022/03/received_297835542392423.jpeg" class="attachment-60x60 size-60x60" alt="" loading="lazy">
                        <?php endif; ?>
                    </div>
                    <hr>
                    <select name="status" id="filter-by-date" class="btn btn-sm btn-outline-secondary" required>
                        <option <?php echo e($photoMess->status == "" ?'selected':''); ?> selected="selected" value="">News status</option>
                        <option <?php echo e($photoMess->status == 1 ?'selected':''); ?> value="1">Active</option>
                        <option <?php echo e($photoMess->status == 0?'selected':''); ?> value="0">Inactive</option>
                    </select>
                   
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <input type="submit" value="Change Status"  class="btn btn-primary">
                </div>
            </div>
        </div>
    </form>
<?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/photo-message/status.blade.php ENDPATH**/ ?>