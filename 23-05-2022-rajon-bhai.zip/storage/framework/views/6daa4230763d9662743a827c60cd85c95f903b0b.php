

<?php $__env->startSection('content'); ?>

            <!-- start page content wrapper-->
			<div class="page-content-wrapper">
				<!-- start page content-->
				<div class="page-content">
				    
					<!--start breadcrumb-->
					<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
						<div class="breadcrumb-title pe-3">Users</div> 
						<a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-sm btn-outline-secondary">Add New</a>
						
						<div class="ms-auto">
							
						</div>
					</div>
					<!--end breadcrumb-->

					<hr>

					<?php echo $__env->make('backend.dashboard.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="successMessage" style="display: none;">
                        <div class="alert alert-success alert-success-custom" role="alert">
                            <i class="fa fa-check"></i>
                            <span class="message"></span>
                        </div>  
                    </div>

					<div class="card">
						<div class="card-body">

							<ul class="nav nav-tabs" id="myTab" role="tablist">
								<li class="nav-item" role="presentation">
									<a class="nav-link <?php echo e($utyUrl == NULL ? 'active' : ''); ?>" href="<?php echo e(route('admin.user.index','')); ?>">
										All <span>(<?php echo e($userCountables->count()); ?>)</span>
									</a>
								</li>
								<li class="nav-item" role="presentation">
									<a class="nav-link <?php echo e($utyUrl == 'administrator' ? 'active' : ''); ?>" href="<?php echo e(route('admin.user.index','administrator')); ?>">
										Administrator
										<span>(<?php echo e($userCountables->where('user_role_id',1)->count()); ?>)</span>
									</a>
								</li>
								<li class="nav-item" role="presentation">
									<a class="nav-link <?php echo e($utyUrl == 'author' ? 'active' : ''); ?>" href="<?php echo e(route('admin.user.index','author')); ?>">
										Author  
										<span>(<?php echo e($userCountables->where('user_role_id',2)->count()); ?>)</span>
									</a>
								</li>
								<li class="nav-item" role="presentation">
									<a class="nav-link <?php echo e($utyUrl == 'contributor' ? 'active' : ''); ?>" href="<?php echo e(route('admin.user.index','contributor')); ?>">
										Contributor  
										<span>(<?php echo e($userCountables->where('user_role_id',3)->count()); ?>)</span>
									</a>
								</li>
								<li class="nav-item" role="presentation">
									<a class="nav-link <?php echo e($utyUrl == 'editor' ? 'active' : ''); ?>" href="<?php echo e(route('admin.user.index','editor')); ?>">
										Editor  
										<span>(<?php echo e($userCountables->where('user_role_id',4)->count()); ?>)</span>
									</a>
								</li>
							</ul>
							<div class="filter-button mt-2">
								<select name="bulk_action" id="filter-by-date" class="bulkActionButton btn btn-sm btn-outline-secondary">
									<option selected="selected" value="0">Bulk actions</option>
									<option value="1">Delete</option>
								</select>
								<button type="button" class="deletedAllButton btn btn-sm btn-outline-secondary">Apply</button>
							</div>

							<div class="tab-content" id="myTabContent">

								<div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="home-tab">
									<div class="table-responsive-sm" style="padding-top: 20px;">
										<table id="post-all" class="table table-striped table-bordered" style="width: 100%;">
											<thead>
												<tr>
													<th style="width: 1%;"><input class="check_all_class " type="checkbox" value="all" name="check_all" style=""></th>
													<th scope="col">Image</th>
													<th scope="col">Name</th>
													<th scope="col">Email</th>
													<th scope="col">Phone</th>
													<th scope="col">Role</th>
													<th scope="col">Posts</th>
												</tr>
											</thead>
											<tbody>
												<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td>
                                                            <?php if($item->user_role_id != 1): ?>
                                                            <input class="check_single_class" type="checkbox"  name="checked_id[]" value="<?php echo e($item->id); ?>" id="<?php echo e($item->id); ?>" style="box-shadow:none;">
                                                            <?php else: ?>
                                                            <input  type="checkbox" disabled style="box-shadow:none;">
                                                            <?php endif; ?>
                                                        </td>
														<td>
															<span class="media-image">
																<?php if($item->photo): ?>
																<img width="60" height="50" src="<?php echo e(asset('storage/user/'.$item->photo)); ?>" class="attachment-60x60 size-60x60" alt="" loading="lazy">
																<?php else: ?>
																<img width="60" height="50" src="" class="attachment-60x60 size-60x60" alt="" loading="lazy">
																<?php endif; ?>
															</span> 
														</td>
														<td>
															<a href="https://motshoprani.org/">  <?php echo e($item->name); ?> </a>
															<div class="group-link">
																<a class="#" href="<?php echo e(route('admin.user.edit',$item->id)); ?>"> Edit</a>  <span class="separetor"> | </span>
                                                                <?php if($item->user_role_id != 1): ?>
                                                                <a class="deleteClass" data-href="<?php echo e(route('admin.user.delete',$item->id)); ?>" href="#"> Trash</a> <span class="separetor"> | </span>
                                                                <?php endif; ?>
																<a class="#" href="<?php echo e(route('admin.user.show',$item->id)); ?>"> View</a>
															</div>
														</td>
														<td> <a href="alam4162@gmail.com">   <?php echo e($item->email); ?> </a> </td>
														<td> <a href="alam4162@gmail.com">   <?php echo e($item->phone ?? NULL); ?> </a> </td>
														<td>
															<?php echo e($item->userRoles ? $item->userRoles->name : NULL); ?>

														</td>
														<td>
															<a href=""><?php echo e($item->postUser ? $item->postUser->count(): 0); ?></a>
														</td>
													</tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
											<tfoot>
												<tr>
													<th style="width: 1%;"><input class="check_all_class " type="checkbox" value="all" name="check_all" style=""></th>
													<th scope="col">Image</th>
													<th scope="col">Name</th>
													<th scope="col">Email</th>
													<th scope="col">Phone</th>
													<th scope="col">Role</th>
													<th scope="col">Posts</th>
												</tr>
											</tfoot>
										</table>
									</div>
								</div>
							
							</div>

						</div>
					</div>
					<!--end Card-->

					
					
				</div>
			    <!-- end page content-->
    		</div>
    		<!--end page content wrapper-->



			<div class="modal modalDeleteShow" id="modalDeleteShow"> </div>
			
<?php $__env->stopSection(); ?>



<?php $__env->startPush('js'); ?>
    <script>
         $(document).on('click','.deleteClass',function(e){
            e.preventDefault();
            url = $(this).data('href');
            $.ajax({
                url:url,
                success:function(response){
                    if(response.status == true)
                    {
                        $('.modalDeleteShow').html(response.html).modal('show');
                    }
                },
            });
        });

         

          // checked all order list 
          $(document).on('click','.check_all_class',function()
            { 
                displayNone();
                if (this.checked == false)
                {   
                    $('.check_single_class').prop('checked', false).change();
                    $(".check_single_class").each(function ()
                    {
                        var id = $(this).attr('id');
                        $(this).val('').change();
                    });
                }
                else
                {
                    $('.check_single_class').prop("checked", true).change();
                    $(".check_single_class").each(function ()
                    {
                        var id = $(this).attr('id');
                        $(this).val(id).change();
                    });
                }
            });
        // checked all order list 

        
        //check single order list
            $(document).on('click','.check_single_class',function()
            {
                displayNone();
                var $b = $('input[type=checkbox]');
                if($b.filter(':checked').length <= 0)
                {
                    $('.check_all_class').prop('checked', false).change();
                }

                var id = $(this).attr('id');
                if (this.checked == false)
                {
                    $(this).prop('checked', false).change();
                    $(this).val('').change();
                }else{
                    $(this).prop("checked", true).change();
                    $(this).val(id).change();
                }
                
                var ids = [];
                $('input.check_single_class[type=checkbox]').each(function () {
                    if(this.checked){
                        var v = $(this).val();
                        ids.push(v);
                    }
                });
                if(ids.length <= 0)
                {
                    $('.check_all_class').prop('checked', false).change();
                }
            });
        //check single order list
            
        //bulk deleting (route for all checked product deleting)
       /*  $(document).on('click', '.deletedAll', function (){
            $('.alert-success').hide();
            $('#delete_modal').modal('show');
        }); */
        

            $(document).on('click', '.deletedAllButton', function (){
                displayNone();
               var option =  $('.bulkActionButton option:selected').val();
               if(option == 0)
               {
                   alert('Select Bulk Action : delete');
                   return 0;
               }
                var ids = [];
                $('input.check_single_class[type=checkbox]').each(function () {
                    if(this.checked){
                        var v = $(this).val();
                        ids.push(v);
                    }
                });
                var url =  "<?php echo e(route('admin.user.bulk.deleting')); ?>";

                if(ids.length <= 0) return ;
                let decirectUrl = "<?php echo e(route('admin.user.index')); ?>";
                $.ajax({
                    url: url,
                    data: {ids: ids},
                    type: "POST",
                    beforeSend:function(){
                        //$('#delete_modal').modal('hide');
                        //$('.loading').fadeIn();
                        //$('.loadingText').show();
                    },
                    success: function(response){
                        if(response.status == true)
                        {
                            $('.successMessage').show();
                            $('.alert-success-custom').show();
                            $('.message').text(response.mess);
                            setTimeout(function () {
                                $(location).attr('href', decirectUrl);
                            }, 2000);
                        }
                    },
                    complete:function(){
                        //$('.loading').fadeOut(); 
                        //$('.loadingText').hide();
                    },
                });
            });
        //bulk product deleting end
            function displayNone()
            {
                $('.alert-success').css({
                    "display" : 'none'
                });
                $('.alert-success-custom').css({
                    "display" : 'none'
                });
                $('.successMessage').hide();
                $('.message').text('');
            }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.dashboard.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/users/index.blade.php ENDPATH**/ ?>