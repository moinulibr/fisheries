

<?php $__env->startSection('content'); ?>
            <!-- start page content wrapper-->
			<div class="page-content-wrapper">
				<!-- start page content-->
				<div class="page-content">
				    
					<!--start breadcrumb-->
					<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
						<div class="breadcrumb-title pe-3">Edit User</div>
						<!--div class="ps-3">
							<nav aria-label="breadcrumb">
								<ol class="breadcrumb mb-0 p-0 align-items-center">
									<li class="breadcrumb-item">
										<a href="javascript:;">
											<ion-icon name="home-outline"></ion-icon>
										</a>
									</li>
									<li class="breadcrumb-item active" aria-current="page">eCommerce</li>
								</ol>
							</nav>
						</div-->
						<div class="ms-auto">
							
						</div>
					</div>
					<!--end breadcrumb-->

					<hr>
					<?php echo $__env->make('backend.dashboard.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


					<div class="card">
						<div class="card-body">
							<form action="<?php echo e(route('admin.user.update',$user->id)); ?>" method="POST" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
								<div class="table-responsive-sm" style="padding-top: 20px;">
									<table class="form-table" role="presentation" style="width: 100%;">
										<tbody>
											<tr class="form-field form-required">
												<th scope="row">
													<label for="email">Email <span class="description">(required)</span></label>
												</th>
												<td><input type="email" class="form-control" disabled value="<?php echo e($user->email); ?>" /></td>
											</tr>
											<tr class="form-field">
												<th scope="row">
													<label for="name">Name <span class="description">(required)</span></label>
												</th>
												<td><input name="name" required type="text" class="form-control" value="<?php echo e(old('name') ?? $user->name); ?>" /></td>
											</tr>
											<tr class="form-field">
												<th scope="row">
													<label for="mobile">Phone <span class="description">(required)</span></label>
												</th>
												<td><input name="phone" required type="phone" class="form-control" value="<?php echo e(old('phone') ?? $user->phone); ?>" /></td>
											</tr>
											<tr class="form-field">
												<th scope="row"><label for="password">Password (required)</label></th>
												<td><input name="password"  type="password" class="form-control" value="" /></td>
											</tr>
											<tr class="form-field">
												<th scope="row"><label for="password">Re-type Password (required)</label></th>
												<td><input name="password_confirmation"  type="password" id="password" class="form-control" value="" /></td>
											</tr>
											
											<tr>
												<th scope="row">Send User Notification</th>
												<td>
													<input type="checkbox" value="1" name="send_user_notification" value="" <?php if($user->send_user_notification == 1): ?> checked="checked" <?php endif; ?>  />
													<label for="send_user_notification">Send the new user an email about their account.</label>
												</td>
											</tr>
											<tr class="form-field">
												<th scope="row"><label for="role">Role <span class="description">(required)</span></label></th>
												<td>
													<select name="user_role_id" id="role" required class="btn btn-sm btn-outline-secondary">
														<?php $__currentLoopData = $userRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
															<option <?php echo e($user->user_role_id == $item->id ?'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
												</td>
											</tr>
											<?php if($user->photo): ?>	
											<tr>
												<th scope="row"></th>
												<th>
													<div class="fileinput fileinput-new" data-provides="fileinput" style=" width: 200px;">
														<img src="<?php echo e(asset('storage/user/'.$user->photo)); ?>" alt="" style="height:120px;  margin-top: 10px;">
													</div>
												</th>
											</tr>
											<?php endif; ?>
											<tr>
												<th scope="row"></th>
												<th>
													<div class="fileinput fileinput-new" data-provides="fileinput" style=" width: 200px;">
														<img id="blah"  />
														<input type='file' name="photo"  onchange="readURL(this);" />
													</div>
													<p>Maximum upload file size: 500 MB.</p>
												</th>
											</tr>
											
											<tr>
												<th scope="row"></th>
												<td>
													<input type="submit" value="Update" class="btn btn-primary" />
												</td>
											</tr>
										</tbody>

									</table>
								</div>
							</form>
						</div>
					</div>
					<!--end Card-->
					
					
				</div>
			    <!-- end page content-->
    		</div>
    		<!--end page content wrapper-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.dashboard.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/users/edit.blade.php ENDPATH**/ ?>