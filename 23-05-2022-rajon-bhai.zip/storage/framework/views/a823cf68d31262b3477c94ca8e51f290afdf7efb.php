

<?php $__env->startSection('content'); ?>

			<!-- start page content wrapper-->
			<div class="page-content-wrapper">
				<!-- start page content-->
				<div class="page-content">
					<!--start breadcrumb-->
					<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
						<div class="breadcrumb-title pe-3">Media Library</div> 
						<a href="<?php echo e(route('admin.media.create')); ?>" class="btn btn-sm btn-outline-secondary">Add New</a>
						<div class="ms-auto">
							
						</div>
					</div>
					<!--end breadcrumb-->

					<hr />

					<div class="card">
						<div class="card-body">
						    
							<div class="table-responsive" style=" padding-top: 10px;">
										<table id="post-pending" class="table table-striped table-bordered" style="width: 100%;">
											<thead>
												<tr>
													<th scope="col">Filter media</th>
												</tr>
											</thead>
											<tbody>
                                                <tr style="width:25%; display: inline-block;">
													<td>
                                                        <a href="main-category.php" class="box">
                                                        <img src="https://akkbd.com/wp-content/uploads/2020/04/Pond_Fish_provatferi-2019-10-15-13-22-05.jpg" alt="image" class="rounded-xl shadow-l gradient-blue" />
                                                        </a>
                                                        <span class="">imge name1</span>
													</td>
												</tr>
                                                <tr style="width:25%; display: inline-block;">
													<td>
                                                        <a href="main-category.php" class="box">
                                                        <img src="https://akkbd.com/wp-content/uploads/2020/04/Pond_Fish_provatferi-2019-10-15-13-22-05.jpg" alt="image" class="rounded-xl shadow-l gradient-blue" />
                                                        </a>
                                                        <span class="">imge name2</span>
													</td>
												</tr>
                                                <tr style="width:25%; display: inline-block;">
													<td>
                                                        <a href="main-category.php" class="box">
                                                        <img src="https://akkbd.com/wp-content/uploads/2020/04/Pond_Fish_provatferi-2019-10-15-13-22-05.jpg" alt="image" class="rounded-xl shadow-l gradient-blue" />
                                                        </a>
                                                        <span class="">imge name3</span>
													</td>
												</tr>
                                                <tr style="width:25%; display: inline-block;">
													<td>
                                                        <a href="main-category.php" class="box">
                                                        <img src="https://akkbd.com/wp-content/uploads/2020/04/Pond_Fish_provatferi-2019-10-15-13-22-05.jpg" alt="image" class="rounded-xl shadow-l gradient-blue" />
                                                        </a>
                                                        <span class="">imge name4</span>
													</td>
												</tr>
                                                <tr style="width:25%; display: inline-block;">
													<td>
                                                        <a href="main-category.php" class="box">
                                                        <img src="https://akkbd.com/wp-content/uploads/2020/04/Pond_Fish_provatferi-2019-10-15-13-22-05.jpg" alt="image" class="rounded-xl shadow-l gradient-blue" />
                                                        </a>
                                                        <span class="">imge name5</span>
													</td>
												</tr>
											</tbody>
										</table>
									</div>
							
						</div>
					</div>
					<!--end card-->
				</div>
				<!-- end page content-->
			</div>
			<!--end page content wrapper-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.dashboard.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/media/grid_view.blade.php ENDPATH**/ ?>