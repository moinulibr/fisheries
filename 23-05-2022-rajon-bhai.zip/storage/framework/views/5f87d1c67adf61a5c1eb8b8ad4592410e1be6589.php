<header class="top-header">
    <nav class="navbar navbar-expand gap-3">
        <div class="mobile-menu-button">
            <i class="bi bi-list"></i>
        </div>
        <form class="searchbar">
            <div class="position-absolute top-50 translate-middle-y search-icon ms-3">
                <i class="bi bi-search"></i>
            </div>
            <input class="form-control" type="text" placeholder="Search for anything" />
            <div class="position-absolute top-50 translate-middle-y search-close-icon">
                <i class="bi bi-x-lg"></i>
            </div>
        </form>
        <div class="top-navbar-right ms-auto">
            <ul class="navbar-nav align-items-center">
                <li class="nav-item mobile-search-button">
                    <a class="nav-link" href="javascript:;">
                        <div class="">
                            <i class="bi bi-search"></i>
                        </div>
                    </a>
                </li>
                
                
                <li class="nav-item dropdown dropdown-user-setting">
                    <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" href="javascript:;" data-bs-toggle="dropdown">
                        <div class="user-setting">
                             <?php if(Auth::guard('web')->user()->photo): ?>
                            <img  src="<?php echo e(asset('storage/user/'.Auth::guard('web')->user()->photo)); ?>" class="user-img" alt="">
                            <?php else: ?>
                            <img src="https://via.placeholder.com/110X110/212529/fff" class="user-img" alt="" />
                            <?php endif; ?>
                        </div>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item" href="javascript:;">
                                <div class="d-flex flex-row align-items-center gap-2">
                                     <?php if(Auth::guard('web')->user()->photo): ?>
                                        <img class="rounded-circle" width="54" height="54" src="<?php echo e(asset('storage/user/'.Auth::guard('web')->user()->photo)); ?>" alt="" >
                                        <?php else: ?>
                                        <img src="https://via.placeholder.com/110X110/212529/fff" alt="" class="rounded-circle" width="54" height="54" />
                                        <?php endif; ?>
                                    <div class="">
                                        <h6 class="mb-0 dropdown-user-name">
                                            <?php echo e(Auth::guard('web')->user()->name); ?>

                                        </h6>
                                        <small class="mb-0 dropdown-user-designation text-secondary">
                                            <?php echo e(Auth::guard('web')->user()->userRoles?Auth::guard('web')->user()->userRoles->name:NULL); ?>

                                        </small>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider" />
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('admin.user.index')); ?>">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <ion-icon name="person-outline"></ion-icon>
                                    </div>
                                    <div class="ms-3"><span>Profile</span></div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('admin.setting.index')); ?>">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <ion-icon name="settings-outline"></ion-icon>
                                    </div>
                                    <div class="ms-3"><span>Setting</span></div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider" />
                        </li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('logout.perform')); ?>">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <ion-icon name="log-out-outline"></ion-icon>
                                    </div>
                                    <div class="ms-3"><span>Logout</span></div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/dashboard/includes/header.blade.php ENDPATH**/ ?>