

<?php $__env->startSection('content'); ?>
            <!-- start page content wrapper-->
			<div class="page-content-wrapper">
				<!-- start page content-->
				<div class="page-content">
				    
					<!--start breadcrumb-->
					<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
						<div class="breadcrumb-title pe-3">Posts</div>
					</div>
					<!--end breadcrumb-->

					<hr />

					<div class="card">
						<div class="card-body">

							<div class="table-responsive-sm" style="padding-top: 20px;">
								<table id="example" class="table table-striped table-bordered" role="presentation" style="width: 100%;">
									<thead>
										<tr>
											<th scope="col">Roles</th>
											
										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $userRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr class="form-field form-required mb-3">
												<th scope="row">
													<label for="user_login"><?php echo e($item->name); ?></label>
												</th>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</tbody>

								</table>
							</div>
						

						</div>
					</div>
					<!--end Card-->



				</div>
			    <!-- end page content-->
    		</div>
    		<!--end page content wrapper-->

<?php $__env->stopSection(); ?>		
<?php echo $__env->make('backend.dashboard.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/users/user_role.blade.php ENDPATH**/ ?>