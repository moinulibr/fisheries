

<?php $__env->startSection('content'); ?>

			<!-- start page content wrapper-->
			<div class="page-content-wrapper">
				<!-- start page content-->
				<div class="page-content">
					<!--start breadcrumb-->
					<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
						<div class="breadcrumb-title pe-3">Upload New Media</div>
					
						<div class="ms-auto">
							
						</div>
					</div>
					<!--end breadcrumb-->

					<hr />
					<?php echo $__env->make('backend.dashboard.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					
					<div class="card">
						<div class="card-body">
							<form action="<?php echo e(route('admin.media.store')); ?>" method="POST" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
								<div class="postbox mb-5">
									<div class="postbox-body">
										<div class="fileinput fileinput-new" data-provides="fileinput">
											<p>files Upload</p>
											<img id="blah"  />
											<input name="photo[]" type='file' onchange="readURL(this);" style="margin-top: 10px;" multiple />
											<p>Maximum upload file size: 500 MB.</p>
											<input type="submit" value="Upload" class="btn btn-primary" />
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
					<!--end card-->
				</div>
				<!-- end page content-->
			</div>
			<!--end page content wrapper-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.dashboard.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Laravel_8\rajon_vai\fisheries\runing\resources\views/backend/media/add_new.blade.php ENDPATH**/ ?>